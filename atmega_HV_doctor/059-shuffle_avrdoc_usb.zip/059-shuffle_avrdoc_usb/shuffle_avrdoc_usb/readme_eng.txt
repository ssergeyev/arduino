ATMEGA FUSEBIT DOCTOR (USB SMD version by Shuffle)
--------------------------------------------------

New firmware and other adapters - on authors web-site http://diy.elektroda.eu/atmega-fusebit-doctor-hvpp/

If you do not need a computer USB-link remove the following components:

X1
DD2
R25
R26
C6
C7

Best regards, Shuffle
2181569@gmail.com